import React, { useState } from 'react';
import { INITIAL_PRODUCTS, INITIAL_LEADS, REVIEWS } from './data/mockData';
import { Product, CartItem, WhatsAppLead } from './types';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { CompareModal } from './components/CompareModal';
import { HomePage } from './pages/HomePage';
import { CatalogPage } from './pages/CatalogPage';
import { ProductDetailPage } from './pages/ProductDetailPage';
import { AdminPortalPage } from './pages/AdminPortalPage';
import { StoreLocationPage } from './pages/StoreLocationPage';

export default function App() {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [leads, setLeads] = useState<WhatsAppLead[]>(INITIAL_LEADS);
  const [activeTab, setActiveTab] = useState<string>('home'); // 'home' | 'iphones' | 'android' | 'pdp' | 'compare' | 'store-location' | 'portal'
  const [selectedProductId, setSelectedProductId] = useState<string>('iphone-16-pro-max');
  
  // Shopping Cart state
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      id: 'cart-1',
      productId: 'iphone-16-pro-max',
      title: 'Apple iPhone 16 Pro Max',
      color: 'Desert Titanium',
      storage: '256GB',
      simVariant: 'USA LL/A (Dual eSIM)',
      price: 185000,
      quantity: 1,
      image: INITIAL_PRODUCTS[0]?.gallery[0]?.src || '',
      condition: 'Brand New',
    },
  ]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Comparison state
  const [compareList, setCompareList] = useState<Product[]>([
    INITIAL_PRODUCTS[0],
    INITIAL_PRODUCTS[1],
  ]);
  const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);

  // Search state
  const [searchQuery, setSearchQuery] = useState('');

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Cart operations
  const handleAddToCart = (item: {
    productId: string;
    title: string;
    color: string;
    storage: string;
    simVariant: string;
    price: number;
    image: string;
    condition: string;
  }) => {
    setCartItems((prev) => {
      const existing = prev.find(
        (it) =>
          it.productId === item.productId &&
          it.color === item.color &&
          it.storage === item.storage
      );
      if (existing) {
        return prev.map((it) =>
          it.id === existing.id ? { ...it, quantity: it.quantity + 1 } : it
        );
      }
      return [
        ...prev,
        {
          id: `cart-${Date.now()}`,
          ...item,
          quantity: 1,
        },
      ];
    });
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((it) => {
          if (it.id === id) {
            const newQty = it.quantity + delta;
            return newQty > 0 ? { ...it, quantity: newQty } : null;
          }
          return it;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (id: string) => {
    setCartItems((prev) => prev.filter((it) => it.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Compare operations
  const handleAddToCompare = (product: Product) => {
    setCompareList((prev) => {
      if (prev.some((p) => p.id === product.id)) {
        showToast(`${product.model} is already in the comparison matrix.`);
        return prev;
      }
      if (prev.length >= 3) {
        showToast('You can compare up to 3 flagships at once.');
        return prev;
      }
      showToast(`Added ${product.model} to comparison!`);
      return [...prev, product];
    });
    setIsCompareModalOpen(true);
  };

  const handleRemoveFromCompare = (productId: string) => {
    setCompareList((prev) => prev.filter((p) => p.id !== productId));
  };

  // Navigation handlers
  const handleSelectProduct = (productId: string) => {
    setSelectedProductId(productId);
    setActiveTab('pdp');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    if (query.trim() && activeTab !== 'iphones' && activeTab !== 'android') {
      setActiveTab('iphones');
    }
  };

  // Admin inventory handlers
  const handleUpdateProductStock = (id: string, delta: number) => {
    setProducts((prev) =>
      prev.map((p) =>
        p.id === id ? { ...p, stock: Math.max(0, p.stock + delta) } : p
      )
    );
  };

  const handleUpdateProductDetails = (id: string, price: number, stock: number) => {
    setProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, basePrice: price, stock } : p))
    );
  };

  const handleAddProduct = (newProduct: Product) => {
    setProducts((prev) => [newProduct, ...prev]);
  };

  const handleDeleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
  };

  // Active product for PDP
  const currentProduct =
    products.find((p) => p.id === selectedProductId) || products[0];

  return (
    <div className="min-h-screen bg-[#f8f9ff] text-[#0b1c30] flex flex-col font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-24 right-6 z-50 bg-[#0b1c30] text-white px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 animate-in fade-in slide-in-from-top-2 border border-white/20">
          <span className="material-symbols-outlined text-[#6ffbbe] text-[20px]">
            check_circle
          </span>
          <span className="text-[13px] font-medium">{toastMessage}</span>
        </div>
      )}

      {/* Main Storefront Header (Hidden when inside full Admin Portal for authentic ops screen) */}
      {activeTab !== 'portal' && (
        <Header
          activeTab={activeTab}
          setActiveTab={(tab) => {
            if (tab === 'compare') {
              setIsCompareModalOpen(true);
            } else {
              setActiveTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }
          }}
          cartItems={cartItems}
          onOpenCart={() => setIsCartOpen(true)}
          onSearch={handleSearch}
          searchQuery={searchQuery}
        />
      )}

      {/* Main Router Content */}
      <main className="flex-1 w-full">
        {activeTab === 'home' && (
          <div className="pt-20">
            <HomePage
              products={products}
              reviews={REVIEWS}
              onSelectProduct={handleSelectProduct}
              onNavigateCatalog={(cat) => {
                if (cat === 'Android') {
                  setActiveTab('android');
                } else {
                  setActiveTab('iphones');
                }
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onNavigateStore={() => {
                setActiveTab('store-location');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onAddToCart={(p) =>
                handleAddToCart({
                  productId: p.id,
                  title: p.title,
                  color: p.colors[0]?.name || 'Default',
                  storage: p.storages[0]?.capacity || '256GB',
                  simVariant: p.simVariants[0]?.name || 'USA LL/A',
                  price: p.basePrice,
                  image: p.gallery[0]?.src || '',
                  condition: p.condition,
                })
              }
            />
          </div>
        )}

        {activeTab === 'iphones' && (
          <div className="pt-20">
            <CatalogPage
              products={products}
              brandFilter="all"
              onSelectProduct={handleSelectProduct}
              onAddToCompare={handleAddToCompare}
              compareList={compareList}
              onNavigateStore={() => {
                setActiveTab('store-location');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          </div>
        )}

        {activeTab === 'android' && (
          <div className="pt-20">
            <CatalogPage
              products={products}
              brandFilter="Samsung"
              onSelectProduct={handleSelectProduct}
              onAddToCompare={handleAddToCompare}
              compareList={compareList}
              onNavigateStore={() => {
                setActiveTab('store-location');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />
          </div>
        )}

        {activeTab === 'pdp' && (
          <div className="pt-20">
            <ProductDetailPage
              product={currentProduct}
              onNavigateHome={() => {
                setActiveTab('home');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onNavigateCatalog={() => {
                setActiveTab('iphones');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              onAddToCart={handleAddToCart}
              onToast={showToast}
            />
          </div>
        )}

        {activeTab === 'store-location' && (
          <div className="pt-20">
            <StoreLocationPage />
          </div>
        )}

        {activeTab === 'portal' && (
          <AdminPortalPage
            products={products}
            leads={leads}
            onUpdateProductStock={handleUpdateProductStock}
            onUpdateProductDetails={handleUpdateProductDetails}
            onAddProduct={handleAddProduct}
            onDeleteProduct={handleDeleteProduct}
            onSelectProduct={handleSelectProduct}
            onBackToStorefront={() => {
              setActiveTab('home');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onToast={showToast}
          />
        )}
      </main>

      {/* Cart Slide-Over Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={handleClearCart}
      />

      {/* Compare Models Modal */}
      <CompareModal
        isOpen={isCompareModalOpen}
        onClose={() => setIsCompareModalOpen(false)}
        products={compareList}
        onSelectProduct={handleSelectProduct}
        onRemoveFromCompare={handleRemoveFromCompare}
      />

      {/* Storefront Footer (Visible on all customer-facing views) */}
      {activeTab !== 'portal' && (
        <Footer
          onNavigate={(tab) => {
            setActiveTab(tab);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />
      )}
    </div>
  );
}

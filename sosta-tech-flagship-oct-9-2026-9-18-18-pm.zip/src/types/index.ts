export interface ColorOption {
  name: string;
  hex: string;
  image?: string;
}

export interface StorageOption {
  capacity: string;
  price: number;
  originalPrice: number;
}

export interface SimOption {
  name: string;
  subtitle: string;
  surcharge: number;
}

export interface TechnicalSpecs {
  display: {
    screenSize: string;
    resolution: string;
    refreshRate: string;
    peakBrightness: string;
    chassisMaterial: string;
  };
  camera: {
    primary: string;
    ultraWide: string;
    telephoto: string;
    cameraControl: string;
    videoRecording: string;
  };
  performance: {
    chipset: string;
    cpuCores: string;
    gpuCores: string;
    neuralEngine: string;
    ram: string;
  };
  battery: {
    playback: string;
    port: string;
    wireless: string;
    wired: string;
  };
  box: {
    inTheBox: string;
    warranty: string;
    replacement: string;
    inspection: string;
  };
  compliance: {
    imeiWhitelisting: string;
    cellular5G: string;
    esimOperators: string;
    invoiceType: string;
  };
}

export interface Product {
  id: string;
  model: string;
  brand: 'Apple' | 'Samsung' | 'Google';
  series: 'iPhone 16 Series' | 'iPhone 15 Series' | 'iPhone 14 Series' | 'iPhone 13 Series' | 'iPhone SE Series' | 'Samsung S Series';
  title: string;
  description: string;
  condition: 'Brand New' | 'Pre-Owned (Like New 99%)' | 'Official Refurbished' | 'Pre-Owned (Like New 98%)';
  batteryHealth?: number; // percentage for pre-owned
  modelIdentifier: string;
  basePrice: number;
  originalPrice: number;
  stock: number;
  stockLocation: string;
  sku: string;
  costPrice: number;
  inStock: boolean;
  preOrderOnly?: boolean;
  featured?: boolean;
  regionVariantBadge: string;
  regionCountryCode: string; // e.g. "USA LL/A", "HK ZA/A"
  colors: ColorOption[];
  storages: StorageOption[];
  simVariants: SimOption[];
  gallery: {
    src: string;
    label: string;
    alt: string;
  }[];
  specs: TechnicalSpecs;
  heroTag?: string;
}

export interface CartItem {
  id: string;
  productId: string;
  title: string;
  color: string;
  storage: string;
  simVariant: string;
  price: number;
  quantity: number;
  image: string;
  condition: string;
}

export interface WhatsAppLead {
  id: string;
  customerName: string;
  phone: string;
  device: string;
  variant: string;
  referenceId: string;
  leadStatus: 'Confirmed (Deposit Paid)' | 'Contacted (Price Offered)' | 'Pending (New Ping)' | 'Completed';
  timestamp: string;
}

export interface Review {
  id: string;
  name: string;
  title: string;
  role: string;
  avatarLetter: string;
  rating: number;
  content: string;
}

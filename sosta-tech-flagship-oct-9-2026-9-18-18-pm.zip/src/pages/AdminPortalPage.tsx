import React, { useState } from 'react';
import { Product, WhatsAppLead } from '../types';
import { BRAND_LOGO_URL } from '../data/mockData';

interface AdminPortalPageProps {
  products: Product[];
  leads: WhatsAppLead[];
  onUpdateProductStock: (id: string, delta: number) => void;
  onUpdateProductDetails: (id: string, price: number, stock: number) => void;
  onAddProduct: (newProduct: Product) => void;
  onDeleteProduct: (id: string) => void;
  onSelectProduct: (productId: string) => void;
  onBackToStorefront: () => void;
  onToast: (msg: string) => void;
}

export const AdminPortalPage: React.FC<AdminPortalPageProps> = ({
  products,
  leads,
  onUpdateProductStock,
  onUpdateProductDetails,
  onAddProduct,
  onDeleteProduct,
  onSelectProduct,
  onBackToStorefront,
  onToast,
}) => {
  // Navigation inside admin
  const [activeAdminNav, setActiveAdminNav] = useState('inventory');
  const [searchFilter, setSearchFilter] = useState('');
  const [conditionFilter, setConditionFilter] = useState<'All' | 'Brand New' | 'Pre-Owned' | 'Refurbished'>('All');

  // Edit Modal State
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editPrice, setEditPrice] = useState<number>(0);
  const [editStock, setEditStock] = useState<number>(0);
  const [editStatus, setEditStatus] = useState<string>('in_stock');
  const [editAuditorNote, setEditAuditorNote] = useState<string>('');
  const [isSavingEdit, setIsSavingEdit] = useState<boolean>(false);

  // Add Phone Modal State
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newModel, setNewModel] = useState('');
  const [newBrand, setNewBrand] = useState<'Apple' | 'Samsung'>('Apple');
  const [newSeries, setNewSeries] = useState<Product['series']>('iPhone 16 Series');
  const [newCondition, setNewCondition] = useState<Product['condition']>('Brand New');
  const [newPrice, setNewPrice] = useState(150000);
  const [newStock, setNewStock] = useState(3);
  const [newStorage, setNewStorage] = useState('256GB');
  const [newColor, setNewColor] = useState('Natural Titanium');

  // Filtered products list
  const filteredInventory = products.filter((p) => {
    if (conditionFilter === 'Brand New' && !p.condition.includes('Brand New')) return false;
    if (conditionFilter === 'Pre-Owned' && !p.condition.includes('Pre-Owned')) return false;
    if (conditionFilter === 'Refurbished' && !p.condition.includes('Refurbished')) return false;

    if (searchFilter.trim()) {
      const q = searchFilter.toLowerCase();
      return (
        p.model.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.regionCountryCode.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleOpenEdit = (p: Product) => {
    setEditingProduct(p);
    setEditPrice(p.basePrice);
    setEditStock(p.stock);
    setEditStatus(p.stock > 1 ? 'in_stock' : 'low_stock');
    setEditAuditorNote('');
  };

  const handleSaveEdit = () => {
    if (!editingProduct) return;
    setIsSavingEdit(true);

    setTimeout(() => {
      onUpdateProductDetails(editingProduct.id, editPrice, editStock);
      setIsSavingEdit(false);
      setEditingProduct(null);
      onToast(`Successfully synced ${editingProduct.model} to Supabase cluster!`);
    }, 600);
  };

  const handleExportCSV = () => {
    const headers = ['Model', 'SKU', 'Condition', 'Base Price BDT', 'Cost Price BDT', 'Stock', 'Location'];
    const rows = products.map((p) => [
      `"${p.model}"`,
      `"${p.sku}"`,
      `"${p.condition}"`,
      p.basePrice,
      p.costPrice,
      p.stock,
      `"${p.stockLocation}"`,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `sosta_tech_inventory_audit_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onToast('Inventory Audit CSV exported successfully!');
  };

  const handleCreateNewProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newModel.trim()) return;

    const id = newModel.toLowerCase().replace(/\s+/g, '-') + '-' + Date.now();
    const createdProduct: Product = {
      id,
      model: newModel,
      brand: newBrand,
      series: newSeries,
      title: `${newBrand} ${newModel}`,
      description: `Newly added verified flagship unit in Rajshahi. Complete warranty coverage.`,
      condition: newCondition,
      modelIdentifier: 'Global Flagship A3299',
      basePrice: Number(newPrice),
      originalPrice: Number(newPrice) + 10000,
      costPrice: Number(newPrice) - 7000,
      stock: Number(newStock),
      stockLocation: 'Theme Omar Plaza, Rajshahi',
      sku: `${newBrand.slice(0, 2).toUpperCase()}-${newModel.slice(0, 6).toUpperCase()}-${newStorage}`,
      inStock: Number(newStock) > 0,
      regionVariantBadge: '🌐 Dual eSIM/SIM',
      regionCountryCode: 'Global / BTRC',
      colors: [{ name: newColor, hex: '#8a8984' }],
      storages: [{ capacity: newStorage, price: Number(newPrice), originalPrice: Number(newPrice) + 10000 }],
      simVariants: [{ name: 'Global Dual', subtitle: 'Nano + eSIM', surcharge: 0 }],
      gallery: [
        {
          src: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBm73k-l7kQ-BokMGRdGorS_xPiOAHL7TH-4r6hrrHdX7RUEbtwhfbzvveZsc8vEkfQzfvOxhxLh-uHdgv4Es_zdbV_nxSOXIk2PZ5_MmnGqbAPH4xxEIJBMYQiYegRCjae7g_YYu1P-XkrExV-upzDhtISTB_K-En8V_chjz3dHF40Sej3tQ4lly8BMhoNg4k_na9kAjmbQTCHK5DYr-TU9gTuCY5MyQWaU739X1EgbjeECgrP8CH7',
          label: `${newModel} Primary Angle`,
          alt: `${newModel} studio photograph`,
        },
      ],
      specs: {
        display: {
          screenSize: '6.7-inch OLED Super Retina',
          resolution: '2796 x 1290 pixels',
          refreshRate: '120Hz ProMotion',
          peakBrightness: '2000 nits',
          chassisMaterial: 'Titanium Grade 5',
        },
        camera: {
          primary: '48MP Pro Main',
          ultraWide: '12MP Ultra Wide',
          telephoto: '12MP 5x Zoom',
          cameraControl: 'Capacitive sensor',
          videoRecording: '4K 120 fps',
        },
        performance: {
          chipset: 'Latest Generation Silicon',
          cpuCores: '6-core',
          gpuCores: '6-core',
          neuralEngine: '16-core NPU',
          ram: '8GB Unified',
        },
        battery: {
          playback: 'Up to 29 hours',
          port: 'USB Type-C',
          wireless: '15W Wireless',
          wired: 'Fast charge 50% in 30 min',
        },
        box: {
          inTheBox: 'Device, Charging Cable',
          warranty: '1 Year Sosta Official Warranty',
          replacement: '7 Days Replacement Guarantee',
          inspection: 'Inspect in person at Theme Omar Plaza',
        },
        compliance: {
          imeiWhitelisting: 'Clean BTRC database record',
          cellular5G: 'Sub-6 GHz & mmWave',
          esimOperators: 'All Bangladesh Operators',
          invoiceType: 'Official Warranty Invoice',
        },
      },
    };

    onAddProduct(createdProduct);
    setIsAddModalOpen(false);
    onToast(`Added ${newModel} to Rajshahi inventory vault!`);
    setNewModel('');
  };

  return (
    <div className="flex bg-[#f8f9ff] min-h-screen text-[#0b1c30]">
      {/* Sidebar (Fixed on left) */}
      <aside className="fixed left-0 top-0 h-full w-64 bg-white border-r border-[#e2e8f0] z-50 flex flex-col justify-between py-6">
        <div className="flex flex-col gap-6">
          {/* Admin Header */}
          <div className="px-6 flex items-center gap-3">
            <img
              alt="Sosta Tech Brand Logo"
              className="h-7 w-auto object-contain"
              src={BRAND_LOGO_URL}
            />
            <div className="flex flex-col">
              <span className="font-semibold text-[18px] text-[#0b1c30] leading-tight">
                Sosta Admin
              </span>
              <span className="text-[11px] text-[#434655] uppercase tracking-wider font-semibold">
                Rajshahi Ops
              </span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="px-3 flex flex-col gap-1">
            <button
              onClick={() => setActiveAdminNav('overview')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-[13px] font-medium transition-colors text-left cursor-pointer ${
                activeAdminNav === 'overview'
                  ? 'bg-[#2563eb] text-white font-semibold'
                  : 'text-[#434655] hover:bg-[#eff4ff] hover:text-[#0b1c30]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">dashboard</span>
              <span>Overview &amp; Sales</span>
            </button>

            <button
              onClick={() => setActiveAdminNav('inventory')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-[13px] font-medium transition-colors text-left cursor-pointer ${
                activeAdminNav === 'inventory'
                  ? 'bg-[#2563eb] text-white font-semibold'
                  : 'text-[#434655] hover:bg-[#eff4ff] hover:text-[#0b1c30]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">devices</span>
              <span>Device Inventory</span>
            </button>

            <button
              onClick={() => setActiveAdminNav('orders')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-[13px] font-medium transition-colors text-left cursor-pointer ${
                activeAdminNav === 'orders'
                  ? 'bg-[#2563eb] text-white font-semibold'
                  : 'text-[#434655] hover:bg-[#eff4ff] hover:text-[#0b1c30]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">local_shipping</span>
              <span>Rajshahi Orders &amp; COD</span>
            </button>

            <button
              onClick={() => setActiveAdminNav('leads')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-[13px] font-medium transition-colors text-left cursor-pointer ${
                activeAdminNav === 'leads'
                  ? 'bg-[#2563eb] text-white font-semibold'
                  : 'text-[#434655] hover:bg-[#eff4ff] hover:text-[#0b1c30]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">chat</span>
              <span>WhatsApp Leads</span>
            </button>

            <button
              onClick={() => setActiveAdminNav('settings')}
              className={`flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-[13px] font-medium transition-colors text-left cursor-pointer ${
                activeAdminNav === 'settings'
                  ? 'bg-[#2563eb] text-white font-semibold'
                  : 'text-[#434655] hover:bg-[#eff4ff] hover:text-[#0b1c30]'
              }`}
            >
              <span className="material-symbols-outlined text-[20px]">store</span>
              <span>Outlet Settings</span>
            </button>
          </nav>
        </div>

        {/* Back to storefront link */}
        <div className="px-4">
          <button
            onClick={onBackToStorefront}
            className="w-full flex items-center gap-2.5 px-3.5 py-2 rounded-lg text-[#434655] hover:bg-[#eff4ff] hover:text-[#0b1c30] transition-colors text-[13px] font-medium cursor-pointer"
          >
            <span className="material-symbols-outlined text-[18px]">storefront</span>
            <span>Back to Storefront</span>
          </button>
        </div>
      </aside>

      {/* Main Body */}
      <div className="pl-64 flex-1 flex flex-col">
        {/* Top Navbar */}
        <header className="fixed top-0 left-64 right-0 h-16 bg-white/90 backdrop-blur-xl border-b border-[#e2e8f0] z-40 flex items-center justify-between px-8">
          <div className="flex items-center gap-3">
            <span className="text-[13px] px-2.5 py-1 rounded bg-[#eff4ff] text-[#0b1c30] font-medium border border-[#e2e8f0]">
              Theme Omar Plaza Outlet
            </span>
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#007d55] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#006242]"></span>
            </span>
            <span className="text-[11px] text-[#006242] font-semibold uppercase tracking-wider">
              Store Active
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-[#434655] text-[13px]">
              <span className="material-symbols-outlined text-[20px]">calendar_today</span>
              <span>Rajshahi Desk</span>
            </div>
            <div className="w-8 h-8 rounded-full bg-[#004ac6] flex items-center justify-center text-white">
              <span className="material-symbols-outlined text-[18px]">person</span>
            </div>
          </div>
        </header>

        {/* Admin Content Area */}
        <main className="pt-20 px-8 py-8 flex flex-col gap-8 max-w-[1560px] w-full">
          {/* Header Action & Realtime Telemetry */}
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-2">
            <div className="flex flex-col gap-1">
              <div className="flex items-center gap-3">
                <h1 className="text-[32px] font-bold text-[#0b1c30] tracking-tight">
                  Inventory &amp; Variant Management
                </h1>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-[#bdffdb]/40 text-[#006242] text-[11px] font-semibold border border-[#007d55]/30">
                  <span className="w-2 h-2 rounded-full bg-[#006242] animate-pulse"></span>
                  Supabase PostgreSQL Live
                </span>
              </div>
              <div className="flex items-center gap-4 text-[#434655] text-[13px]">
                <span>
                  Logged in as: <strong className="text-[#0b1c30]">admin@sostatech.bd</strong> (Super Admin)
                </span>
                <span className="text-[#c3c6d7]">•</span>
                <span>
                  Cluster: <span className="font-mono text-[12px]">raj-node-01.prod</span>
                </span>
                <span className="text-[#c3c6d7]">•</span>
                <span>
                  Latency: <span className="text-[#006242] font-bold">18ms</span>
                </span>
              </div>
            </div>

            <div className="flex items-center gap-3 self-start lg:self-center">
              <button
                onClick={handleExportCSV}
                className="px-4 py-2.5 rounded-lg bg-[#eff4ff] hover:bg-[#e5eeff] text-[#0b1c30] text-[13px] font-semibold transition-all flex items-center gap-2 border border-[#e2e8f0] cursor-pointer"
              >
                <span className="material-symbols-outlined text-[18px]">ios_share</span>
                <span>Export Audit (.CSV)</span>
              </button>
              <button
                onClick={() => setIsAddModalOpen(true)}
                className="px-5 py-2.5 rounded-lg bg-[#004ac6] hover:bg-[#2563eb] text-white text-[13px] font-semibold transition-all flex items-center gap-2 shadow-md cursor-pointer"
              >
                <span className="material-symbols-outlined text-[19px]">add_circle</span>
                <span>+ Add New Phone</span>
              </button>
            </div>
          </div>

          {/* 4 KPI Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5">
            {/* KPI 1 */}
            <div className="bg-white p-6 rounded-xl shadow-xs border border-[#e2e8f0] flex flex-col justify-between relative overflow-hidden group">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[11px] uppercase tracking-wider text-[#434655] font-bold">
                  Active Stock Level
                </span>
                <span className="p-2 rounded-lg bg-[#eff4ff] text-[#004ac6]">
                  <span className="material-symbols-outlined text-[20px]">warehouse</span>
                </span>
              </div>
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="text-[32px] font-bold text-[#0b1c30]">
                    {products.reduce((acc, p) => acc + p.stock, 0)}
                  </span>
                  <span className="text-[13px] text-[#434655]">Devices in Vault</span>
                </div>
                <div className="mt-2.5 flex items-center justify-between text-[13px]">
                  <span className="text-[#434655]">Asset Value:</span>
                  <span className="text-[14px] text-[#0b1c30] font-bold">
                    ৳
                    {products
                      .reduce((acc, p) => acc + p.basePrice * p.stock, 0)
                      .toLocaleString('en-IN')}
                  </span>
                </div>
              </div>
              <div className="w-full bg-[#eff4ff] h-1.5 rounded-full mt-4 overflow-hidden">
                <div className="bg-[#004ac6] h-full rounded-full" style={{ width: '78%' }}></div>
              </div>
            </div>

            {/* KPI 2 */}
            <div className="bg-white p-6 rounded-xl shadow-xs border border-[#e2e8f0] flex flex-col justify-between relative overflow-hidden group">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[11px] uppercase tracking-wider text-[#434655] font-bold">
                  Inquiries Today
                </span>
                <span className="p-2 rounded-lg bg-[#eff4ff] text-[#006242]">
                  <span className="material-symbols-outlined text-[20px]">mark_chat_unread</span>
                </span>
              </div>
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="text-[32px] font-bold text-[#0b1c30]">19</span>
                  <span className="text-[13px] text-[#006242] font-semibold">WhatsApp Leads</span>
                </div>
                <div className="mt-2.5 flex items-center justify-between text-[13px]">
                  <span className="text-[#434655]">Converted to Deal:</span>
                  <span className="text-[13px] text-[#006242] font-bold">8 Confirmed (42.1%)</span>
                </div>
              </div>
              <div className="w-full bg-[#eff4ff] h-1.5 rounded-full mt-4 overflow-hidden">
                <div className="bg-[#006242] h-full rounded-full" style={{ width: '42%' }}></div>
              </div>
            </div>

            {/* KPI 3 */}
            <div className="bg-white p-6 rounded-xl shadow-xs border border-[#e2e8f0] flex flex-col justify-between relative overflow-hidden group">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[11px] uppercase tracking-wider text-[#ba1a1a] font-bold">
                  Low Stock Alerts
                </span>
                <span className="p-2 rounded-lg bg-[#ffdad6]/50 text-[#ba1a1a]">
                  <span className="material-symbols-outlined text-[20px]">warning</span>
                </span>
              </div>
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="text-[32px] font-bold text-[#ba1a1a]">
                    {products.filter((p) => p.stock <= 2).length}
                  </span>
                  <span className="text-[13px] text-[#434655]">Critical SKUs</span>
                </div>
                <div className="mt-2.5 flex items-center justify-between text-[13px]">
                  <span className="text-[#434655]">Replenish Action:</span>
                  <span className="text-[13px] text-[#ba1a1a] font-semibold">Need PO in 48h</span>
                </div>
              </div>
              <div className="w-full bg-[#eff4ff] h-1.5 rounded-full mt-4 overflow-hidden">
                <div className="bg-[#ba1a1a] h-full rounded-full" style={{ width: '25%' }}></div>
              </div>
            </div>

            {/* KPI 4 */}
            <div className="bg-white p-6 rounded-xl shadow-xs border border-[#e2e8f0] flex flex-col justify-between relative overflow-hidden group">
              <div className="flex items-center justify-between mb-4">
                <span className="text-[11px] uppercase tracking-wider text-[#434655] font-bold">
                  Pre-Owned Inventory
                </span>
                <span className="p-2 rounded-lg bg-[#eff4ff] text-[#565e74]">
                  <span className="material-symbols-outlined text-[20px]">verified</span>
                </span>
              </div>
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="text-[32px] font-bold text-[#0b1c30]">
                    {products.filter((p) => p.condition.includes('Pre-Owned')).length}
                  </span>
                  <span className="text-[13px] text-[#434655]">Graded Handsets</span>
                </div>
                <div className="mt-2.5 flex items-center justify-between text-[13px]">
                  <span className="text-[#434655]">Avg Tested Health:</span>
                  <span className="text-[13px] text-[#0b1c30] font-bold">94% Battery</span>
                </div>
              </div>
              <div className="w-full bg-[#eff4ff] h-1.5 rounded-full mt-4 overflow-hidden">
                <div className="bg-[#565e74] h-full rounded-full" style={{ width: '94%' }}></div>
              </div>
            </div>
          </div>

          {/* Interactive Inventory Table */}
          <div className="bg-white rounded-xl shadow-xs border border-[#e2e8f0] flex flex-col overflow-hidden">
            {/* Filter Bar */}
            <div className="p-5 bg-white flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#eff4ff]">
              <div className="flex items-center gap-3 flex-1 max-w-lg">
                <div className="relative w-full">
                  <span className="material-symbols-outlined absolute left-3.5 top-1/2 -translate-y-1/2 text-[#434655] text-[20px]">
                    search
                  </span>
                  <input
                    type="text"
                    value={searchFilter}
                    onChange={(e) => setSearchFilter(e.target.value)}
                    placeholder="Search by model, IMEI, SKU code, or storage variant..."
                    className="w-full pl-10 pr-4 py-2.5 bg-[#eff4ff] rounded-lg text-[#0b1c30] text-[13px] focus:outline-none focus:ring-2 focus:ring-[#004ac6]/30 border border-[#e2e8f0]"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2.5 flex-wrap">
                <div className="flex items-center bg-[#eff4ff] rounded-lg p-1 border border-[#e2e8f0]">
                  {(['All', 'Brand New', 'Pre-Owned', 'Refurbished'] as const).map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setConditionFilter(tab)}
                      className={`px-3 py-1.5 rounded text-[13px] font-semibold transition-all cursor-pointer ${
                        conditionFilter === tab
                          ? 'bg-white text-[#0b1c30] shadow-xs'
                          : 'text-[#434655] hover:text-[#0b1c30]'
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
                <button
                  onClick={() => setSearchFilter('')}
                  className="p-2.5 rounded-lg bg-[#eff4ff] hover:bg-[#e5eeff] text-[#434655] border border-[#e2e8f0]"
                  title="Filter options"
                >
                  <span className="material-symbols-outlined text-[20px]">filter_list</span>
                </button>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-[#eff4ff]/60 text-[#434655] text-[11px] uppercase tracking-wider border-b border-[#eff4ff]">
                    <th className="py-4 px-6 font-semibold">Device &amp; Model</th>
                    <th className="py-4 px-4 font-semibold">Condition</th>
                    <th className="py-4 px-4 font-semibold">Variant / Specs</th>
                    <th className="py-4 px-4 font-semibold">Unit Price</th>
                    <th className="py-4 px-4 font-semibold">Stock Qty</th>
                    <th className="py-4 px-4 font-semibold">Battery</th>
                    <th className="py-4 px-4 font-semibold">Status</th>
                    <th className="py-4 px-6 font-semibold text-right">Quick Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#eff4ff] text-[13px] text-[#0b1c30]">
                  {filteredInventory.map((phone) => (
                    <tr key={phone.id} className="hover:bg-[#f8f9ff] transition-colors group">
                      <td className="py-4 px-6">
                        <div className="flex items-center gap-3.5">
                          <div className="w-12 h-12 rounded-lg bg-[#eff4ff] p-1.5 flex items-center justify-center shrink-0 border border-[#e2e8f0]">
                            <img
                              className="w-full h-full object-contain"
                              alt={phone.title}
                              src={phone.gallery[0]?.src || ''}
                            />
                          </div>
                          <div className="flex flex-col">
                            <span className="text-[15px] text-[#0b1c30] font-bold tracking-tight">
                              {phone.model}
                            </span>
                            <span className="text-[#434655] text-[11px] font-mono">
                              SKU: {phone.sku}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-4 px-4">
                        <span
                          className={`inline-flex items-center px-2.5 py-1 rounded-full text-[11px] font-semibold ${
                            phone.condition.includes('Brand New')
                              ? 'bg-[#dbe1ff] text-[#00174b]'
                              : phone.condition.includes('Refurbished')
                              ? 'bg-[#dce9ff] text-[#0b1c30]'
                              : 'bg-[#dae2fd] text-[#131b2e]'
                          }`}
                        >
                          {phone.condition}
                        </span>
                      </td>

                      <td className="py-4 px-4">
                        <div className="flex flex-col">
                          <span className="text-[13px] font-medium text-[#0b1c30]">
                            {phone.storages[0]?.capacity} • {phone.colors[0]?.name}
                          </span>
                          <span className="text-[#434655] text-[12px]">
                            {phone.regionVariantBadge} ({phone.regionCountryCode})
                          </span>
                        </div>
                      </td>

                      <td className="py-4 px-4">
                        <div className="flex flex-col">
                          <span className="text-[16px] font-bold text-[#0b1c30]">
                            ৳ {phone.basePrice.toLocaleString('en-IN')}
                          </span>
                          <span className="text-[#434655] text-[11px] font-mono">
                            Cost: ৳{phone.costPrice.toLocaleString('en-IN')}
                          </span>
                        </div>
                      </td>

                      <td className="py-4 px-4">
                        <div className="inline-flex items-center gap-2 bg-[#eff4ff] px-2.5 py-1 rounded-lg border border-[#e2e8f0]">
                          <button
                            onClick={() => onUpdateProductStock(phone.id, -1)}
                            className="text-[#434655] hover:text-[#0b1c30] font-bold text-base leading-none px-1 cursor-pointer"
                          >
                            −
                          </button>
                          <span className="text-[13px] font-bold w-4 text-center">{phone.stock}</span>
                          <button
                            onClick={() => onUpdateProductStock(phone.id, 1)}
                            className="text-[#434655] hover:text-[#0b1c30] font-bold text-base leading-none px-1 cursor-pointer"
                          >
                            +
                          </button>
                        </div>
                      </td>

                      <td className="py-4 px-4">
                        {phone.batteryHealth ? (
                          <span className="inline-flex items-center gap-1 text-[#006242] font-semibold text-[13px]">
                            <span className="material-symbols-outlined text-[16px]">
                              battery_charging_full
                            </span>
                            {phone.batteryHealth}%
                          </span>
                        ) : (
                          <span className="text-[#434655] font-mono text-[12px]">N/A (100%)</span>
                        )}
                      </td>

                      <td className="py-4 px-4">
                        {phone.stock <= 2 ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#ffdad6]/40 text-[#ba1a1a] text-[11px] font-semibold">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#ba1a1a] animate-ping"></span>
                            Low Stock
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#bdffdb]/40 text-[#006242] text-[11px] font-semibold">
                            <span className="w-1.5 h-1.5 rounded-full bg-[#006242]"></span>
                            In Stock
                          </span>
                        )}
                      </td>

                      <td className="py-4 px-6 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => handleOpenEdit(phone)}
                            className="p-2 rounded-lg hover:bg-[#eff4ff] text-[#434655] hover:text-[#004ac6] transition-colors cursor-pointer"
                            title="Edit Pricing & Stock"
                          >
                            <span className="material-symbols-outlined text-[19px]">edit</span>
                          </button>
                          <button
                            onClick={() => onSelectProduct(phone.id)}
                            className="p-2 rounded-lg hover:bg-[#eff4ff] text-[#434655] hover:text-[#0b1c30] transition-colors cursor-pointer"
                            title="View Public Catalog"
                          >
                            <span className="material-symbols-outlined text-[19px]">open_in_new</span>
                          </button>
                          <button
                            onClick={() => {
                              onDeleteProduct(phone.id);
                              onToast(`Archived ${phone.model}`);
                            }}
                            className="p-2 rounded-lg hover:bg-[#eff4ff] text-[#434655] hover:text-[#ba1a1a] transition-colors cursor-pointer"
                            title="Archive SKU"
                          >
                            <span className="material-symbols-outlined text-[19px]">delete</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Pagination & Table Footer */}
            <div className="p-4 bg-white flex flex-col sm:flex-row items-center justify-between gap-4 text-[13px] text-[#434655] border-t border-[#eff4ff]">
              <span>
                Showing <strong className="text-[#0b1c30]">1 - {filteredInventory.length}</strong> of{' '}
                <strong>42</strong> verified devices across Rajshahi Hub
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  disabled
                  className="px-3 py-1.5 rounded bg-[#eff4ff] text-[#434655] text-[12px] font-medium disabled:opacity-40"
                >
                  Previous
                </button>
                <span className="px-3 py-1.5 rounded bg-[#004ac6] text-white text-[12px] font-bold">
                  1
                </span>
                <button className="px-3 py-1.5 rounded bg-[#eff4ff] text-[#0b1c30] hover:bg-[#e5eeff] text-[12px] font-medium">
                  2
                </button>
                <button className="px-3 py-1.5 rounded bg-[#eff4ff] text-[#0b1c30] hover:bg-[#e5eeff] text-[12px] font-medium">
                  3
                </button>
                <button className="px-3 py-1.5 rounded bg-[#eff4ff] text-[#0b1c30] hover:bg-[#e5eeff] text-[12px] font-medium">
                  Next
                </button>
              </div>
            </div>
          </div>

          {/* Recent WhatsApp Customer Inquiries Panel */}
          <div className="bg-white rounded-xl shadow-xs border border-[#e2e8f0] p-6 flex flex-col gap-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-lg bg-[#bdffdb]/40 text-[#006242]">
                  <span className="material-symbols-outlined text-[24px]">chat</span>
                </div>
                <div>
                  <h2 className="text-[20px] font-bold text-[#0b1c30] tracking-tight">
                    Recent WhatsApp Customer Inquiries
                  </h2>
                  <p className="text-[13px] text-[#434655]">
                    Live lead synchronization via Rajshahi Omar Plaza customer desk
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#eff4ff] text-[#0b1c30] text-[11px] font-semibold border border-[#e2e8f0]">
                  <span className="w-2 h-2 rounded-full bg-[#006242]"></span>
                  Sync Active (Webhook: Port 8443)
                </span>
                <span className="px-3 py-1.5 rounded-lg bg-[#eff4ff] text-[#0b1c30] text-[13px] font-medium">
                  View All ({leads.length})
                </span>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-[#eff4ff]/60 text-[#434655] text-[11px] uppercase tracking-wider border-b border-[#eff4ff]">
                    <th className="py-3 px-4 font-semibold">Customer</th>
                    <th className="py-3 px-4 font-semibold">Inquired Device &amp; Variant</th>
                    <th className="py-3 px-4 font-semibold">Reference ID</th>
                    <th className="py-3 px-4 font-semibold">Lead Status</th>
                    <th className="py-3 px-4 font-semibold text-right">Direct Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#eff4ff] text-[13px]">
                  {leads.map((lead) => (
                    <tr key={lead.id} className="hover:bg-[#f8f9ff] transition-colors">
                      <td className="py-3.5 px-4">
                        <div className="flex flex-col">
                          <span className="font-semibold text-[#0b1c30]">{lead.customerName}</span>
                          <span className="text-[#434655] font-mono text-[12px]">{lead.phone}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="flex flex-col">
                          <span className="text-[#0b1c30] font-medium">{lead.device}</span>
                          <span className="text-[#434655] text-[12px]">{lead.variant}</span>
                        </div>
                      </td>

                      <td className="py-3.5 px-4">
                        <span className="font-mono text-[11px] text-[#434655] bg-[#eff4ff] px-2 py-0.5 rounded border border-[#e2e8f0]">
                          {lead.referenceId}
                        </span>
                      </td>

                      <td className="py-3.5 px-4">
                        <span
                          className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-semibold ${
                            lead.leadStatus.includes('Confirmed')
                              ? 'bg-[#bdffdb]/50 text-[#006242]'
                              : lead.leadStatus.includes('Contacted')
                              ? 'bg-[#dbe1ff] text-[#004ac6]'
                              : 'bg-[#eff4ff] text-[#434655]'
                          }`}
                        >
                          {lead.leadStatus}
                        </span>
                      </td>

                      <td className="py-3.5 px-4 text-right">
                        <a
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#006242] hover:bg-[#007d55] text-white text-[12px] font-semibold transition-all shadow-xs"
                          href={`https://wa.me/${lead.phone.replace(/[^0-9]/g, '')}?text=Hello%20${encodeURIComponent(
                            lead.customerName
                          )},%20regarding%20your%20inquiry%20${lead.referenceId}%20for%20${encodeURIComponent(
                            lead.device
                          )}...`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <span className="material-symbols-outlined text-[16px]">forum</span>
                          <span>Open WhatsApp</span>
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      </div>

      {/* Slide-Over Modal: Quick Stock & Price Update */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-end bg-[#0b1c30]/40 backdrop-blur-xs transition-opacity duration-200">
          <div className="w-full max-w-md h-full bg-white shadow-2xl flex flex-col justify-between p-6 overflow-y-auto border-l border-[#e2e8f0]">
            <div className="flex flex-col gap-6">
              {/* Header */}
              <div className="flex items-center justify-between pb-4 border-b border-[#eff4ff]">
                <div className="flex flex-col">
                  <span className="text-[11px] uppercase tracking-wider text-[#004ac6] font-bold">
                    Fast DB Sync
                  </span>
                  <h3 className="text-[20px] text-[#0b1c30] font-bold">
                    Quick Stock &amp; Price Update
                  </h3>
                </div>
                <button
                  onClick={() => setEditingProduct(null)}
                  className="p-2 rounded-lg hover:bg-[#eff4ff] text-[#434655] hover:text-[#0b1c30]"
                >
                  <span className="material-symbols-outlined text-[20px]">close</span>
                </button>
              </div>

              {/* Sync Indicator */}
              <div className="flex items-center gap-2 p-3 rounded-lg bg-[#bdffdb]/40 text-[#006242] text-[13px] border border-[#007d55]/20 font-medium">
                <span className="material-symbols-outlined text-[18px]">cloud_sync</span>
                <span>
                  Instant commit to <strong>public.store_variants</strong> table
                </span>
              </div>

              {/* Target Info */}
              <div className="bg-[#eff4ff] p-4 rounded-xl flex flex-col gap-1 border border-[#e2e8f0]">
                <span className="text-[18px] text-[#0b1c30] font-bold">{editingProduct.model}</span>
                <span className="text-[#004ac6] text-[13px] font-semibold">
                  {editingProduct.condition}
                </span>
                <span className="text-[#434655] text-[13px]">
                  {editingProduct.storages[0]?.capacity} • {editingProduct.colors[0]?.name} •{' '}
                  {editingProduct.regionVariantBadge}
                </span>
              </div>

              {/* Form Fields */}
              <div className="flex flex-col gap-4">
                <div className="flex flex-col gap-1.5">
                  <label className="text-[13px] font-semibold text-[#0b1c30]">
                    Customer Retail Price (BDT ৳)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-[#434655]">
                      ৳
                    </span>
                    <input
                      type="number"
                      value={editPrice}
                      onChange={(e) => setEditPrice(Number(e.target.value))}
                      className="w-full pl-9 pr-4 py-2.5 rounded-lg bg-[#eff4ff] text-[#0b1c30] text-[14px] font-semibold focus:bg-white focus:ring-2 focus:ring-[#004ac6] focus:outline-none border border-[#e2e8f0]"
                    />
                  </div>
                  <span className="text-[11px] text-[#434655]">
                    Standard pricing threshold for Rajshahi retail desk
                  </span>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-[13px] font-semibold text-[#0b1c30]">
                    Physical Units in Vault
                  </label>
                  <div className="flex items-center gap-3">
                    <input
                      type="number"
                      value={editStock}
                      onChange={(e) => setEditStock(Math.max(0, Number(e.target.value)))}
                      className="w-full px-4 py-2.5 rounded-lg bg-[#eff4ff] text-[#0b1c30] text-[14px] font-semibold focus:bg-white focus:ring-2 focus:ring-[#004ac6] focus:outline-none border border-[#e2e8f0]"
                    />
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setEditStock((s) => Math.max(0, s - 1))}
                        className="w-10 h-10 rounded-lg bg-[#eff4ff] hover:bg-[#e5eeff] font-bold text-lg text-[#0b1c30] flex items-center justify-center border border-[#e2e8f0]"
                      >
                        −
                      </button>
                      <button
                        onClick={() => setEditStock((s) => s + 1)}
                        className="w-10 h-10 rounded-lg bg-[#eff4ff] hover:bg-[#e5eeff] font-bold text-lg text-[#0b1c30] flex items-center justify-center border border-[#e2e8f0]"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-[13px] font-semibold text-[#0b1c30]">
                    Inventory Status Override
                  </label>
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-lg bg-[#eff4ff] text-[#0b1c30] text-[13px] focus:outline-none focus:ring-2 focus:ring-[#004ac6] border border-[#e2e8f0]"
                  >
                    <option value="in_stock">In Stock (Publicly Available)</option>
                    <option value="low_stock">Low Stock Warning</option>
                    <option value="reserved">Reserved / Customer Token Held</option>
                    <option value="out_of_stock">Out of Stock</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-[13px] font-semibold text-[#0b1c30]">
                    Auditor Note (Internal)
                  </label>
                  <textarea
                    rows={2}
                    value={editAuditorNote}
                    onChange={(e) => setEditAuditorNote(e.target.value)}
                    placeholder="e.g. Received shipment batch B-90 from Dhaka HQ via Sundarban Courier"
                    className="w-full p-3 rounded-lg bg-[#eff4ff] text-[#0b1c30] text-[13px] focus:outline-none focus:ring-2 focus:ring-[#004ac6] border border-[#e2e8f0]"
                  ></textarea>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-6 border-t border-[#eff4ff]">
              <button
                onClick={() => setEditingProduct(null)}
                className="w-1/2 py-2.5 rounded-lg bg-[#eff4ff] hover:bg-[#e5eeff] text-[#0b1c30] text-[13px] font-semibold transition-all border border-[#e2e8f0]"
              >
                Cancel
              </button>
              <button
                disabled={isSavingEdit}
                onClick={handleSaveEdit}
                className="w-1/2 py-2.5 rounded-lg bg-[#004ac6] hover:bg-[#2563eb] text-white text-[13px] font-semibold transition-all shadow-md flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                {isSavingEdit ? (
                  <span className="material-symbols-outlined text-[18px] animate-spin">refresh</span>
                ) : (
                  <span className="material-symbols-outlined text-[18px]">check</span>
                )}
                <span>{isSavingEdit ? 'Syncing...' : 'Save Changes'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add New Phone Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0b1c30]/40 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-lg bg-white rounded-2xl shadow-2xl p-6 border border-[#e2e8f0]">
            <div className="flex items-center justify-between pb-4 border-b border-[#eff4ff]">
              <div>
                <h3 className="text-[20px] font-bold text-[#0b1c30]">Add New Flagship SKU</h3>
                <p className="text-[12px] text-[#434655]">Register a new device into Rajshahi Hub Vault</p>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-2 rounded-lg hover:bg-[#eff4ff] text-[#434655]"
              >
                <span className="material-symbols-outlined text-[20px]">close</span>
              </button>
            </div>

            <form onSubmit={handleCreateNewProduct} className="py-4 space-y-4 text-[13px]">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-[#0b1c30] block mb-1">Brand</label>
                  <select
                    value={newBrand}
                    onChange={(e) => setNewBrand(e.target.value as 'Apple' | 'Samsung')}
                    className="w-full h-10 px-3 rounded-lg bg-[#eff4ff] border border-[#e2e8f0]"
                  >
                    <option value="Apple">Apple</option>
                    <option value="Samsung">Samsung</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-[#0b1c30] block mb-1">Series</label>
                  <select
                    value={newSeries}
                    onChange={(e) => setNewSeries(e.target.value as Product['series'])}
                    className="w-full h-10 px-3 rounded-lg bg-[#eff4ff] border border-[#e2e8f0]"
                  >
                    <option value="iPhone 16 Series">iPhone 16 Series</option>
                    <option value="iPhone 15 Series">iPhone 15 Series</option>
                    <option value="iPhone 14 Series">iPhone 14 Series</option>
                    <option value="Samsung S Series">Samsung S Series</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-[#0b1c30] block mb-1">Device Model Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. iPhone 16 Plus or Galaxy S24+"
                  value={newModel}
                  onChange={(e) => setNewModel(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg bg-[#eff4ff] border border-[#e2e8f0]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-[#0b1c30] block mb-1">Condition</label>
                  <select
                    value={newCondition}
                    onChange={(e) => setNewCondition(e.target.value as Product['condition'])}
                    className="w-full h-10 px-3 rounded-lg bg-[#eff4ff] border border-[#e2e8f0]"
                  >
                    <option value="Brand New">Brand New (Sealed Pack)</option>
                    <option value="Pre-Owned (Like New 99%)">Pre-Owned (Like New 99%)</option>
                    <option value="Official Refurbished">Official Refurbished</option>
                  </select>
                </div>
                <div>
                  <label className="font-semibold text-[#0b1c30] block mb-1">Storage</label>
                  <select
                    value={newStorage}
                    onChange={(e) => setNewStorage(e.target.value)}
                    className="w-full h-10 px-3 rounded-lg bg-[#eff4ff] border border-[#e2e8f0]"
                  >
                    <option value="128GB">128GB</option>
                    <option value="256GB">256GB</option>
                    <option value="512GB">512GB</option>
                    <option value="1TB">1TB</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-[#0b1c30] block mb-1">Base Price (৳)</label>
                  <input
                    type="number"
                    value={newPrice}
                    onChange={(e) => setNewPrice(Number(e.target.value))}
                    className="w-full h-10 px-3 rounded-lg bg-[#eff4ff] border border-[#e2e8f0] font-semibold"
                  />
                </div>
                <div>
                  <label className="font-semibold text-[#0b1c30] block mb-1">Initial Stock Units</label>
                  <input
                    type="number"
                    min="1"
                    value={newStock}
                    onChange={(e) => setNewStock(Number(e.target.value))}
                    className="w-full h-10 px-3 rounded-lg bg-[#eff4ff] border border-[#e2e8f0] font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-[#0b1c30] block mb-1">Primary Color Finish</label>
                <input
                  type="text"
                  placeholder="e.g. Natural Titanium / Desert / Black"
                  value={newColor}
                  onChange={(e) => setNewColor(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg bg-[#eff4ff] border border-[#e2e8f0]"
                />
              </div>

              <div className="flex items-center gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="w-1/2 py-2.5 rounded-lg bg-[#eff4ff] hover:bg-[#e5eeff] text-[#0b1c30] font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2.5 rounded-lg bg-[#004ac6] hover:bg-[#2563eb] text-white font-semibold shadow-md"
                >
                  Add Device to Vault
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
